const express = require("express");  // Import express to create a router
const router = express.Router({ mergeParams: true });  // Create a router instance and mergeParams to access params from the parent route
const wrapAsync = require("../utils/wrapAsync");  // Utility function to handle async errors
const { validateReview, isLoggedIn, isReviewAuthor } = require("../middleware.js");  // Import middleware functions for validation and authentication
const reviewController = require("../controllers/reviews.js");  // Import the reviews controller

// Create Review Route: Handle POST request to add a new review
router.post(
    "/",  // POST route to create a new review for a specific listing
    isLoggedIn,  // Ensure the user is logged in before submitting a review
    validateReview,  // Validate the review data
    wrapAsync(reviewController.createReview)  // Handle review creation asynchronously
);

// Delete Review Route: Handle DELETE request to remove a review
router.delete(
    "/:reviewId",  // DELETE route to remove a specific review by its ID
    isLoggedIn,  // Ensure the user is logged in before deleting a review
    isReviewAuthor,  // Ensure the user is the author of the review before allowing deletion
    wrapAsync(reviewController.destroyReview)  // Handle review deletion asynchronously
);

module.exports = router;  // Export the router for use in other parts of the application
