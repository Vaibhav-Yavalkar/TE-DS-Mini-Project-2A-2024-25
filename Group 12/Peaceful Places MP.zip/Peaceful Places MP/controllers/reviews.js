// review.js
const Listing = require("../models/listing");  // Import the Listing model
const Review = require("../models/review");  // Import the Review model

module.exports.createReview = async (req, res) => {
    console.log(req.body);  // Log request body to check if review[comment] is present
    const { id } = req.params;  // Get listing id from the URL
    const listing = await Listing.findById(id).populate("reviews");  // Find listing and populate reviews
    
    const newReview = new Review(req.body.review);  // Create a new review using form data
    newReview.author = req.user._id;  // Set the current user as the author of the review

    listing.reviews.push(newReview);  // Add new review to the listing's reviews
    await newReview.save();  // Save the new review
    await listing.save();  // Save the updated listing with the new review

    req.flash("success", "Review Created");  // Show success message
    res.redirect(`/listings/${listing._id}`);  // Redirect to the listing's page
}

module.exports.destroyReview = async (req, res) => {
    const { id, reviewId } = req.params;  // Get listing and review id from the URL

    // Remove the review from the listing and delete the review itself
    await Listing.findByIdAndUpdate(id, { $pull: { reviews: reviewId } });
    await Review.findByIdAndDelete(reviewId);

    req.flash("success", "Review Deleted");  // Show success message
    res.redirect(`/listings/${id}`);  // Redirect to the listing's page
};
