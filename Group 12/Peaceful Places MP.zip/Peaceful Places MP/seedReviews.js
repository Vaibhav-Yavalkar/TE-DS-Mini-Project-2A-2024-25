// seedReviews.js
const mongoose = require("mongoose");
const Review = require("./models/review"); // Import the Review model
const Listing = require("./models/listing"); // Import the Listing model
const faker = require("faker"); // Optional: Use faker to generate random data

// Connect to the MongoDB database
mongoose.connect("mongodb://localhost:27017/wanderlust", {
    useNewUrlParser: true,
    useUnifiedTopology: true,
});

// Function to generate a random review
const generateRandomReview = (listingId) => {
    return {
        comment: faker.lorem.sentence(), // Random comment
        rating: Math.floor(Math.random() * 5) + 1, // Random rating between 1 and 5
        author: mongoose.Types.ObjectId(), // Dummy author id
    };
};

// Function to seed random reviews
const seedRandomReviews = async () => {
    const listings = await Listing.find(); // Get all listings

    for (const listing of listings) {
        const randomReviewCount = Math.floor(Math.random() * 5) + 1; // Random number of reviews (1-5)

        for (let i = 0; i < randomReviewCount; i++) {
            const newReview = generateRandomReview(listing._id); // Generate a random review
            const review = new Review(newReview); // Create a new Review instance
            listing.reviews.push(review); // Add review to the listing's reviews
            await review.save(); // Save the review to the database
        }

        await listing.save(); // Save the updated listing
    }

    console.log("Random reviews seeded successfully!");
    mongoose.connection.close(); // Close the connection after seeding
};

// Run the seed function
seedRandomReviews().catch((error) => {
    console.error("Error seeding random reviews:", error);
    mongoose.connection.close(); // Close the connection on error
});
