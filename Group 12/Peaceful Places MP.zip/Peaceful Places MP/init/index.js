// const mongoose = require("mongoose");
// const data = require("./data");
// const Listing = require("../models/listing");

// const MONGO_URL = "mongodb://127.0.0.1:27017/peacefulplaces";

// main()
//     .then(() => {
//         console.log("connected to database");
//     })
//     .catch((err) => {
//         console.log(err);
//     });


// async function main() {
//     await mongoose.connect(MONGO_URL);
// }

// const initDB = async() => {
//      await Listing.deleteMany({});
//      initData.data.map((obj) => ({...obj, owner:"67010504c9eb6320d0a623f1"}) );
//      await Listing.collection.insertMany(initData.data);
//      console.log("data was initailized");
// };

// initDB();

const mongoose = require("mongoose");
const data = require("./data"); // Importing the data
const Listing = require("../models/listing");

const MONGO_URL = "mongodb://127.0.0.1:27017/peacefulplaces";

main()
    .then(() => {
        console.log("connected to database");
    })
    .catch((err) => {
        console.log(err);
    });

async function main() {
    await mongoose.connect(MONGO_URL);
}

const initDB = async() => {
     await Listing.deleteMany({});
     const modifiedData = data.map((obj) => ({ ...obj, owner: "67010504c9eb6320d0a623f1" })); // Referencing data correctly
     await Listing.collection.insertMany(modifiedData);
     console.log("data was initialized");
};

initDB();
