const mongoose = require("mongoose");  // Import mongoose to interact with MongoDB
const Schema = mongoose.Schema;  // Create a schema object for defining models
const Review = require("./review.js");  // Import the Review model for linking reviews to listings

// Define the schema for a listing
const listingSchema = new Schema({
    title: {
        type: String,
        required: true,  // Title is required for each listing
    },
    description: String,  // Optional description field for the listing
    image: {    
        type: String,
        default: "https://www.stayadventurous.com/wp-content/uploads/2018/01/Goa-Sunset-900.jpg",  // Default image URL
    },
    price: Number,  // Price for the listing
    location: String,  // Location of the listing
    country: String,  // Country where the listing is located
    reviews: [
        {
            type: Schema.Types.ObjectId,  // Store references to the associated reviews
            ref: "Review",  // Reference the Review model
        },
    ],
    owner: {
        type: Schema.Types.ObjectId,  // Store the owner's user ID
        ref: "User",  // Reference the User model
    }
});

// Virtual field to calculate the average rating of a listing
listingSchema.virtual("averageRating").get(function () {
    if (this.reviews.length === 0) return 0;  // Return 0 if there are no reviews

    const total = this.reviews.reduce((sum, review) => sum + review.rating, 0);
    return total / this.reviews.length;
});

// Middleware to run after deleting a listing
listingSchema.post("findOneAndDelete", async (listing) => {
    if (listing) {
        // If the listing is deleted, remove all associated reviews
        await Review.deleteMany({ _id: { $in: listing.reviews } });
    }
});

// Create the Listing model from the schema
const Listing = mongoose.model("Listing", listingSchema);
module.exports = Listing;  // Export the Listing model for use in other files
