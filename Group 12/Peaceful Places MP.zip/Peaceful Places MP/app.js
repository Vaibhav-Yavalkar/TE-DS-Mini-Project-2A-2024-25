require('dotenv').config(); // Load environment variables from .env file

// Import required modules
const express = require("express"); // Framework for building web applications
const app = express(); // Create an instance of Express
const mongoose = require("mongoose"); // MongoDB object modeling tool
const path = require("path"); // Utilities for working with file and directory paths
const methodOverride = require("method-override"); // Middleware for HTTP method override
const ejsMate = require("ejs-mate"); // EJS template engine extension
const ExpressError = require("./utils/ExpressError"); // Custom error handling class
const session = require('express-session'); // Session management middleware
const flash = require('connect-flash'); // Flash messaging middleware
const passport = require("passport"); // Authentication middleware
const LocalStrategy = require("passport-local"); // Local authentication strategy
const User = require("./models/user.js"); // User model

// Import route modules
const listingRouter = require("./routes/listing.js");
const reviewRouter = require("./routes/review.js");
const userRouter = require("./routes/user.js");

// MongoDB connection URL
const MONGO_URL = "mongodb://127.0.0.1:27017/wanderlust";

// Connect to the MongoDB database
main()
    .then(() => {
        console.log("Connected to DB"); // Log connection success
    })
    .catch((err) => {
        console.log(err); // Log connection error
    });

// Function to connect to MongoDB
async function main() {
    await mongoose.connect(MONGO_URL); // Establish connection to the database
}

// Set EJS as the view engine and specify views directory
app.set("view engine", "ejs");
app.set("views", path.join(__dirname, "views"));

// Middleware to parse URL-encoded bodies (form submissions)
app.use(express.urlencoded({ extended: true }));

// Middleware to support HTTP method override (e.g., DELETE and PUT)
app.use(methodOverride("_method"));

// Use EJS Mate for extended EJS functionality
app.engine('ejs', ejsMate);

// Serve static files from the "public" directory
app.use(express.static(path.join(__dirname, "public")));

// Configure session middleware options
const sessionOptions = {
    secret: "mysupersecret", // Secret for session signing
    resave: false, // Don't save session if unmodified
    saveUninitialized: true, // Save uninitialized session
    cookie: {
        expires: Date.now() + 7 * 24 * 60 * 60 * 1000, // Cookie expiry time (1 week)
        maxAge: 7 * 24 * 60 * 60 * 1000, // Max age for the cookie
        httpOnly: true, // Prevent client-side JavaScript from accessing the cookie
    },
};

// Use session and flash middleware
app.use(session(sessionOptions));
app.use(flash()); // Enable flash messages

// Initialize Passport.js for authentication
app.use(passport.initialize());
app.use(passport.session()); // Use sessions with Passport

// Configure Passport to use the LocalStrategy for authentication
passport.use(new LocalStrategy(User.authenticate()));

// Serialize and deserialize user instances to and from the session
passport.serializeUser(User.serializeUser());
passport.deserializeUser(User.deserializeUser());

// Middleware to pass flash messages and current user info to templates
app.use((req, res, next) => {
    res.locals.success = req.flash("success"); // Store success messages
    res.locals.error = req.flash("error"); // Store error messages
    res.locals.currUser = req.user; // Store current logged-in user
    next(); // Proceed to the next middleware
});

// Define routes
app.use("/listings", listingRouter); // Listings routes
app.use("/listings/:id/reviews", reviewRouter); // Reviews routes
app.use("/", userRouter); // User authentication routes

// Catch-all route for undefined routes
app.all("*", (req, res, next) => {
    next(new ExpressError(404, "Page Not Found")); // Create a 404 error
});

// Error handling middleware
app.use((err, req, res, next) => {
    const { statusCode = 500, message = "Something went wrong" } = err; // Destructure error properties
    res.status(statusCode).render("error.ejs", { message }); // Render error page with message
});

// Start the server and listen on port 8080
app.listen(8080, () => {
    console.log("Server is listening on port 8080"); // Log server start
});
