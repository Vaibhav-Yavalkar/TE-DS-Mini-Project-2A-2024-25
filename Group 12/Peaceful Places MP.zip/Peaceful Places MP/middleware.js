const Listing = require("./models/listing"); // Import the Listing model
const Review = require("./models/review"); // Import the Review model
const ExpressError = require("./utils/ExpressError"); // Import custom error handling class
const { listingSchema, reviewSchema } = require("./schema.js"); // Import Joi schemas for validation

// Middleware to check if the user is logged in
module.exports.isLoggedIn = (req, res, next) => {
    if (!req.isAuthenticated()) { // Check if the user is authenticated
        req.session.redirectUrl = req.originalUrl; // Store the original URL to redirect after login
        req.flash("error", "You must be logged in to create listings!"); // Flash an error message
        return res.redirect("/login"); // Redirect to login page
    }
    next(); // Proceed to the next middleware if authenticated
}

// Middleware to save the redirect URL
module.exports.saveRedirectUrl = (req, res, next) => {
    if (req.session.redirectUrl) { // Check if there is a redirect URL stored
        res.locals.redirectUrl = req.session.redirectUrl; // Pass the URL to the response locals
    }
    next(); // Proceed to the next middleware
}

// Middleware to check if the user is the owner of the listing
module.exports.isOwner = async (req, res, next) => {
    const { id } = req.params; // Get listing ID from request parameters
    let listing = await Listing.findById(id); // Find the listing by ID

    if (!listing.owner.equals(req.user._id)) { // Check if the user is the owner
        req.flash("error", "You are not the owner of this listing"); // Flash an error message
        return res.redirect(`/listings/${id}`); // Redirect to the listing page
    }
    next(); // Proceed to the next middleware if the user is the owner
}

// Middleware to validate listing data
module.exports.validateListing = (req, res, next) => {
    let { error } = listingSchema.validate(req.body); // Validate request body against the schema
    if (error) { // If validation fails
        let errMsg = error.details.map((el) => el.message).join(","); // Create error message
        throw new ExpressError(400, errMsg); // Throw a custom error with status code 400
    } else {
        next(); // Proceed to the next middleware if validation passes
    }
};

// Middleware to validate review data
module.exports.validateReview = (req, res, next) => {
    let { error } = reviewSchema.validate(req.body); // Validate request body against the review schema
    if (error) { // If validation fails
        let errMsg = error.details.map((el) => el.message).join(","); // Create error message
        throw new ExpressError(400, errMsg); // Throw a custom error with status code 400
    } else {
        next(); // Proceed to the next middleware if validation passes
    }
};

// Middleware to check if the user is the author of the review
module.exports.isReviewAuthor = async (req, res, next) => {
    const { id, reviewId } = req.params; // Get listing and review IDs from request parameters
    let review = await Review.findById(reviewId); // Find the review by ID

    if (!review.author.equals(res.locals.currUser._id)) { // Check if the current user is the author
        req.flash("error", "You are not the author of this review; you cannot delete this review"); // Flash an error message
        return res.redirect(`/listings/${id}`); // Redirect to the listing page
    }
    next(); // Proceed to the next middleware if the user is the author
}
